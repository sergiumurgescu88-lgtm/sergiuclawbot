# SOUL.md - TestBiz

> Generare AI indisponibila. Editati manual.
