# OpenClaw Agent - TestBiz
Generat de AgentulMeu.online

Fisiere:
- SOUL.md
- IDENTITY.md

Instalare:
1. Copiaza folderul in ~/.openclaw/workspace/
2. openclaw start

Suport: contact@agentulmeu.online
